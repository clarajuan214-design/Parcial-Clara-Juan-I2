# Diccionario — I2: resistencia del hormigón

Unidad de observación: registro de ensayo de una mezcla a una edad determinada. CSV UTF-8, coma separadora y punto decimal. Ocho predictores y un objetivo. No hay códigos de faltantes documentados; cero en un componente indica ausencia válida, no una orden de imputación.

| Campo | Unidad | Descripción / papel |
|---|---|---|
| cemento | kg/m³ | Cemento de la receta; predictor |
| escoria | kg/m³ | Escoria de alto horno; predictor |
| ceniza_volante | kg/m³ | Ceniza volante; predictor |
| agua | kg/m³ | Agua de la receta; predictor |
| superplastificante | kg/m³ | Aditivo superplastificante; predictor |
| agregado_grueso | kg/m³ | Agregado grueso de la mezcla; predictor |
| agregado_fino | kg/m³ | Agregado fino de la mezcla; predictor |
| edad_dias | días | Edad de ensayo; predictor |
| resistencia_mpa | MPa | Resistencia a compresión; objetivo |
| id_ensayo | sin unidad | Fila original (1–1.030); trazabilidad, nunca predictor |
| grupo_receta | sin unidad | Código para coincidencia exacta de los siete componentes, sin edad ni resistencia; nunca predictor |

Las cantidades no son porcentajes ni tienen que sumar 100. Los grupos de edad para diagnóstico se fijan en hasta 7, más de 7 hasta 28 y más de 28 días; no son categorías predictoras. El CSV de particiones contiene id_ensayo, grupo_receta y particion, sin etiquetas. Las particiones son train, validacion y prueba.

Vocabulario: variable predictora (*feature*), variable objetivo (*target*), entrenamiento (*training*), validación (*validation*) y prueba (*test*). `train` es el nombre del archivo/partición de entrenamiento.
