# Fuentes, licencia y curación — I2

Yeh, I. (1998). Concrete Compressive Strength. UCI Machine Learning Repository. DOI 10.24432/C5PK67.

- Ficha: https://archive.ics.uci.edu/dataset/165/concrete+compressive+strength
- Descarga: https://archive.ics.uci.edu/static/public/165/concrete+compressive+strength.zip
- Licencia: Creative Commons Atribución 4.0, https://creativecommons.org/licenses/by/4.0/
- Descarga y verificación: 18/9/2026. Miembro: Concrete_Data.xls, primera fila como encabezado.
- SHA-256 ZIP: dad85d14de8aee4e07479daa774e6b569a313715b71a3b92c95a07cf91c2c9a7
- SHA-256 del CSV convertido sin curación: d11d18e168b01a06c53cdb3c2bf605551e27a6a0419114abc25f8fd849412e28

Conversión XLS mediante pandas y xlrd 2.0.2; 1.030 filas, 9 columnas originales. Se conservan todas las mediciones y 25 repeticiones completas; no hay identificador original de réplica para determinar su causa. No se imputan ni recortan datos. Se traducen encabezados y se crea id_ensayo como orden original.

grupo_receta se crea con coincidencia exacta de los siete componentes y factorize(sort=True). Se aplica GroupShuffleSplit con train_size=0,7 y random_state=42; sobre los grupos restantes, test_size=0,5 y random_state=42. Se obtienen 729/148/153 ensayos y 299/64/65 recetas. Ningún grupo cruza conjuntos. Las 25 repeticiones quedan en entrenamiento por esta asignación, sin búsqueda de semillas. Los CSV de las tres particiones reproducen exactamente el piloto de coordinación.

Los grupos son sólo identidades de composición: no garantizan independencia entre fórmulas cercanas ni laboratorios. Las edades varían dentro de una receta. La validación se usa para elegir entre cuatro candidatos y prueba se reserva para candidato y referencias. No hay reajuste con validación.

Cambios docentes: nombres en español, identificadores, particiones y guía; fuente original sin alteración de valores. Atribución conservada; la fuente no avala conclusiones. El análisis no diseña mezclas ni certifica resistencia estructural.
