# I2 — Resistencia del hormigón

1. Extraer el ZIP completo conservando datasets/ junto al notebook.
2. Abrir I2_Parcial_resistencia_hormigon.ipynb con Python 3 (entorno de revisión: Python 3.13.15) y dependencias de requirements.txt. En Colab, cargar datasets/ en el directorio de trabajo.
3. Resolver las diez consignas en dos semanas. Los datos y el contexto básico funcionan sin red.
4. Abrir prueba sólo después de registrar selección en C7. No alterar CSV ni agrupamientos.
5. Entregar notebook ejecutado con respuestas e interpretaciones junto a datasets/.

El esqueleto contiene soporte, no soluciones. Ejecutarlo vacío comprueba la carga, pero no resuelve el parcial.
